//=============================================
// C++ Programming in easy steps 4ed. [9:160]
//=============================================

// Uncomment the 3 directive lines below to avoid duplicate function defintion...
// #ifndef ADD_H
//  #define ADD_H

  inline int add (int x , int y ) { return ( x + y ) ; }

// #endif