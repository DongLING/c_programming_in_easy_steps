//=============================================
// C++ Programming in easy steps 4ed. [9:160]
//=============================================

#include "add.h"
#include "triple.h"

#include <iostream>
using namespace std ;

int main()
{
  cout << "9 + 3 = " << add( 9 , 3 ) << endl ;

  cout << "9 x 3 = " << triple( 9 ) << endl ;

  return 0 ;
}
