//=============================================
// C++ Programming in easy steps 4ed. [9:153]
//=============================================

#include <iostream>
using namespace std ;

int main()
{
  cerr << "This is a simple test program" << endl ;

  return  0 ;
}
