//=============================================
// C++ Programming in easy steps 4ed. [9:160]
//=============================================

#include "C:/Users/Mike/Desktop/add.h" // Adjust path to suit.
#include "C:/Users/Mike/Desktop/triple.h" // Adjust path to suit.

#include <iostream>
using namespace std ;

int main()
{
  cout << "9 + 3 = " << add( 9 , 3 ) << endl ;

  cout << "9 x 3 = " << triple( 9 ) << endl ;
  system("PAUSE");
  return 0 ;
}
