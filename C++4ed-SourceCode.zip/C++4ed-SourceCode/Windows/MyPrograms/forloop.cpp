//=============================================
// C++ Programming in easy steps 4ed. [3:48]
//=============================================

#include <iostream>
using namespace std ;

int main()
{
  int i , j ;

  for ( i = 1 ; i < 4 ; i++ )
  {  
    cout <<  "Loop iteration: " << i << endl ;

    // Uncomment the lines below to add the nested loop.
    // for ( j = 1 ; j < 4 ; j++ )
    // {
    //   cout << "    Inner loop iteration: " << j << endl ;
    // }
  }

  return 0 ;
}
