//=============================================
// C++ Programming in easy steps 4ed. [1:12]
//=============================================

#include <iostream>
using namespace std ;

// A C++ Program to output a greeting.

int main()
{
  cout << "Hello World!" << endl  ;
  return 0 ;
}
