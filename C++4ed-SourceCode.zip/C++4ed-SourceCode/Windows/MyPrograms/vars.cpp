//=============================================
// C++ Programming in easy steps 4ed. [1:17]
//=============================================

#include <iostream>
using namespace std ;

int main()
{
  char letter ; letter = 'A' ;
  int number ; number = 100 ;
  float decimal = 7.5 ;
  double pi = 3.14159 ;
  bool isTrue = false ;

  cout << "char letter: " << letter << endl ;
  cout << "int number: " << number << endl ;
  cout << "float decimal: " << decimal << endl ;
  cout << "double pi: "  << pi << endl ;
  cout << "bool isTrue: " << isTrue << endl ;

  return 0 ;
}
