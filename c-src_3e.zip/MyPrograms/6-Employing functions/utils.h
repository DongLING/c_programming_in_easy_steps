

int square( int num )
{
  return( num * num ) ;
}
