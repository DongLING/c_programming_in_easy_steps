//=============================================
// C++ Programming in easy steps 3ed. [9:160]
//=============================================

#ifndef ADD_H
	#define ADD_H

		inline int add( int x , int y ){ return ( x + y ) ; } 

#endif
