//=============================================
// C++ Programming in easy steps 3ed. [9:154]
//=============================================


// Comment out the next two lines for command-line definition.
#define BOOK "C++ Programming in easy steps"
#define NUM 200

#define RULE "*****************************"


#include <iostream>
using namespace std ;

int main()
{
	cout << RULE << endl << BOOK << endl << RULE ;

	cout << endl << "NUM is: " << NUM << endl ;

	cout << "Double NUM: " << ((NUM) * 2)  << endl ;

	return 0 ;
}

